/**
 *
 * @author Taiwo Kolajo
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
//import javax.swing.border.MatteBorder;
//import weka.M5PExample;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.core.Instances;
//import misc.SplashScreen;
//import misc.Splash;

public class Menu extends JFrame {
    JMenuBar menubar;
    JMenu data;
    JMenuItem loadData;
    JMenuItem csvArff;
    JMenuItem exit;
    
    JMenu clustering;
    JMenuItem simpleKMeans;
    JMenuItem em;
    
    JMenu help;
    JMenuItem about;
    
    
    
    public Menu(){
        super("Churn Management System");
        setLayout(new FlowLayout());
        menubar =new JMenuBar();
        setJMenuBar(menubar);
        data = new JMenu("File");
        menubar.add(data);
        loadData = new JMenuItem("Load Data");
        data.add(loadData);
        csvArff = new JMenuItem("Convert CSV to ARFF format");
        data.add(csvArff);
        exit = new JMenuItem("Exit");
        data.add(exit);

        clustering = new JMenu("Clustering");
        menubar.add(clustering);
        simpleKMeans = new JMenuItem("SimpleKMeans");
        clustering.add(simpleKMeans);
        em = new JMenuItem("EM");
        clustering.add(em);

       /* classification = new JMenu("Classification");
        menubar.add(classification);
        decisionStump = new JMenuItem("DecisionStump");
        classification.add(decisionStump);
        repTree = new JMenuItem("RepTree");
        classification.add(repTree);
        m5p = new JMenuItem("M5P");
        classification.add(m5p);*/

        help = new JMenu("Help");
        menubar.add(help);
        about = new JMenuItem("About");
        help.add(about);

        event e = new event();
        loadData.addActionListener(e);
        csvArff.addActionListener(e);
        simpleKMeans.addActionListener(e);
        em.addActionListener(e);
        /*decisionStump.addActionListener(e);
        repTree.addActionListener(e);
        m5p.addActionListener(e);*/
        about.addActionListener(e);
        exit.addActionListener(e);

        //showSpashScreen();

       
    }
    public class event implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==exit) {
                System.exit(0);
            } else if (e.getSource()==loadData){
                System.out.println("Loading data...");//
                //Create a JFileChooser
                JFileChooser fileChooser = new JFileChooser();
               int choice =  fileChooser.showOpenDialog(null);
               //if the user selects yes or open
               if (choice == JFileChooser.APPROVE_OPTION) {
                    try {
                        //Get the selected file dat the user chose
                        File file = fileChooser.getSelectedFile();
                        
                        // load CSV
                        CSVLoader loader = new CSVLoader();
                        loader.setSource(file);
                        Instances data = loader.getDataSet();
                        // save ARFF
                        ArffSaver saver = new ArffSaver();
                        saver.setInstances(data);

                        //Ask the user to select a file where to save the
                        //ARFF to.
                        JOptionPane.showMessageDialog(null,
                                "Please enter a file name where you want to save the ARFF.");
                        
                        choice = fileChooser.showSaveDialog(null);
                        if (choice == JFileChooser.APPROVE_OPTION) {
                            File nFile = fileChooser.getSelectedFile();
                            String fn = nFile.getName();
                            if (!fn.endsWith(".Arff")) {
                                fn.concat(".Arff");
                                String pathName = nFile.getPath();

                                nFile.delete();
                                nFile = new File(pathName+fn);
                            }
                            saver.setFile(nFile);
//                            saver.setDestination(nFile);
                            saver.writeBatch();
                            
                        }

                       
                        ////COPIED CODE ENDS
                    } catch (IOException ex) {
                        Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   ////COPIED CODE ENDS
               }
            } else if (e.getSource() == simpleKMeans) {
                
                
                 String filename="";
                 JFileChooser fileChooser= new JFileChooser();
                 JOptionPane.showMessageDialog(null, "Select the Arff file.");
                 int ch = fileChooser.showOpenDialog(null);
                 if (ch == JFileChooser.APPROVE_OPTION) {
                     File f = fileChooser.getSelectedFile();
                     filename = f.getAbsolutePath();
                      int numc = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of clusters."));
                     try {
                        ClusteringSimpleKMeans clusteringSimpleKMeans = new ClusteringSimpleKMeans(filename, numc);
                    } catch (Exception ex) {
                        Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                 } else {
                     JOptionPane.showMessageDialog(null, "You have not selected the Arff file.");
                 }
                
            } else if (e.getSource() == em){
                 String filename="";
                 JFileChooser fileChooser= new JFileChooser();
                 JOptionPane.showMessageDialog(null, "Select the Arff file.");
                 int ch = fileChooser.showOpenDialog(null);
                int numc = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of clusters."));
                if (ch == JFileChooser.APPROVE_OPTION) {
                     File f = fileChooser.getSelectedFile();
                     filename = f.getAbsolutePath();
                }
                try {

                    ClusteringEM clusteringEM = new ClusteringEM(filename, numc);
                } catch (Exception ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
 /*   public void showSpashScreen(){

        Icon logoIcon = new ImageIcon( getClass().getResource( "misc/logo.jpg" ) );

 // create new JLabel for logo
 JLabel logoLabel = new JLabel( logoIcon );

 // set JLabel background color
 logoLabel.setBackground( Color.white );

 // set splash screen border
 logoLabel.setBorder(
 new MatteBorder( 5, 5, 5, 5, Color.black ) );

 // make logoLabel opaque
 logoLabel.setOpaque( true );

 // create SplashScreen for logo
 SplashScreen splash = new SplashScreen( logoLabel );

 // show SplashScreen for 3 seconds
 splash.showSplash(3);

    }*/
    public static void main(String args[]){


        Menu gui = new Menu();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setSize(500,350);
        gui.setVisible(true);
    }

}

