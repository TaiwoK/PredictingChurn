/**
 *
 * @author Taiwo Kolajo
 */
import weka.core.Instances;
//import weka.clusterers.DensityBasedClusterer;
import weka.clusterers.EM;
import weka.clusterers.ClusterEvaluation;

import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JOptionPane;

public class ClusteringEM {
     /**
   * Run clusterers
   *
   * @param filename      the name of the ARFF file to run on
     * @param numClusters
     * @throws java.lang.Exception
   */
  public ClusteringEM(String filename, int numClusters) throws Exception {
    ClusterEvaluation eval;
    Instances               data;
    String[]                options;
    weka.clusterers.EM   cl;

//    data = new Instances(new BufferedReader(new FileReader("C:\\Thesis\\cluster2.Arff")));
     data = new Instances(new BufferedReader(new FileReader(filename)));
    
    // normal
    System.out.println("\n--> normal");
    options    = new String[2];
    options[0] = "-t";
    options[1] = filename;
    cl   = new weka.clusterers.EM();
    cl.setNumClusters(numClusters);
    System.out.println(
        ClusterEvaluation.evaluateClusterer(cl, options));
    
    // manual call
    System.out.println("\n--> manual");
    
    cl.buildClusterer(data);
    eval = new ClusterEvaluation();

    eval.setClusterer(cl);
    
    eval.evaluateClusterer(new Instances(data));
    System.out.println("# of clusters: " + eval.getNumClusters());
    
    // density based
    System.out.println("\n--> density (CV)");
    cl   = new EM();
    eval = new ClusterEvaluation();
    eval.setClusterer(cl);
    ClusterEvaluation.crossValidateModel(cl, data, 10, data.getRandomNumberGenerator(1));
    System.out.println("# of clusters: " + eval.getNumClusters());
  }

  /**
   * usage:
   *   ClusteringEM Arff-file
     * @param args
     * @throws java.lang.Exception
   */
  public static void main(String[] args) throws Exception {
    if (args.length == 1) {
      System.out.println("usage: " + ClusteringEM.class.getName() + " <arff-file>");
      System.exit(1);
    }
int numc = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of clusters."));
   ClusteringEM clusteringEM =new ClusteringEM("cluster2.Arff", numc);
  }
    
}
