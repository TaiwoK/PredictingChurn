﻿Implementation in Java to predict customer churn

How to set up



First, you need to make sure that you have Java Editor, JDK 1.7, weka 3+, wekar.jar and weka-src.jar (weka libraries) installed on your system. Then follow the following steps to run the application:

Dataset: SUMMARIZEDCALLRECORDS.csv
The dataset in csv format was converted to Arff format called cluster2.Arff

The dataset consists of the the listed attributes in the following order:

Subscriber 				# telecom customer represented by a unique id

Call Ratio 				#the proportion of calls which has been made by each subscriber to his/her total number of calls (incoming and outgoing calls)

Average Call Distance 	#the average time distance between one’s calls

Life 					# the period of time in the observed time span in which each subscriber has been active.

Max Distance 			# the maximum time distance between two calls of a specific subscriber in the observed period

Max Date 				# the last date in our observed period in which a subscriber has made a call

Min Date 				# the first date in our observed period in which a subscriber has made a call

No of Days 				# number of days in which a specific subscriber has made or received a call

Total No In 			# the total number of incoming calls for each subscriber in the observed period

Total No Out 			# the total number of outgoing calls for each subscriber in the observed period

Total Cost 				# the total money that each subscriber has been charged for using the services in the specific time period under study

Total Duration In 		# the total duration of incoming calls (in Sec) for a specific subscriber in the observed time span

Total Duration Out 		#The total duration of outgoing calls (in Sec) for a specific subscriber in our observed time span


To convert your dataset in csv format to Arff format
Create a new project in your Java Editor (e.g. NetBeans, IntelliJ IDEA, Eclipse, Jdeveloper, etc.)
create new files and copy
The implementation codes are subdivided into:
1. Menu.java : Application interface. This interacts with the user to run ClusteringSimpleKMeans.java and ClusteringEM.java

2. ClusteringSimpleKMeans.java : This is used to group the customers according to their calling pattern.
The user will be prompted to supply the number of clusters. Once you supply the number of clusters, 
the customer records (cluster2.Arff) will then be grouped using the customer data based on the number of cluster supplied.

3.2. ClusteringEM.java : This is the same as above. But the result generated is measured by the log likelihood value. 
The log likelihood measures how well an algorithm has performed; the closer to zero the better the performance of the algorithm. 

User can then make their choice based on the log likelihood value. 

The algorithm with better log likelihood value is then selected and the result can be 
ploted in graph using each of the above listed attributes to actually determine the subscribers who are likely to churn. 
for example, a cluster with high average call distance implies that the subscribers are not making call regularly and may likely churn.



